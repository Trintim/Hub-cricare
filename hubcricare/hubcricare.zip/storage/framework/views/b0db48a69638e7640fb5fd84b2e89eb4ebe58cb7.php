<?php if($errors->any()): ?>
<div class="alert alert-danger alert-elevate col-sm-12" role="alert">
    <div class="alert-icon"><i class="
        flaticon-exclamation-1 text-light"></i></div>
    <div class="alert-text">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Fechar">
            <span aria-hidden="true"><i class="la la-close"></i></span>
        </button>
    </div>
</div>
<?php endif; ?>

<?php if(Session::has('danger')): ?>
<div class="alert alert-danger alert-elevate col-sm-12" role="alert">
    <div class="alert-icon"><i class="
        flaticon-exclamation-1 text-light"></i></div>
    <div class="alert-text">
        <?php echo e(Session::get('danger')); ?><br>
    </div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Fechar">
            <span aria-hidden="true"><i class="la la-close"></i></span>
        </button>
    </div>
</div>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
<div class="alert alert-warning alert-elevate col-sm-12" role="alert">
    <div class="alert-icon"><i class="
        flaticon-warning text-light"></i></div>
    <div class="alert-text text-light">
        <?php echo e(Session::get('warning')); ?><br>
    </div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Fechar">
            <span aria-hidden="true"><i class="la la-close"></i></span>
        </button>
    </div>
</div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-elevate col-sm-12" role="alert">
    <div class="alert-icon"><i class="
    flaticon2-checkmark text-light"></i></div>
    <div class="alert-text">
        <?php echo e(Session::get('success')); ?><br>
    </div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Fechar">
            <span aria-hidden="true"><i class="la la-close"></i></span>
        </button>
    </div>
</div>
<?php endif; ?>

<?php if(Session::has('info')): ?>
<div class="alert alert-info alert-elevate col-sm-12" role="alert">
    <div class="alert-icon"><i class="
        fa fa-info text-light"></i></div>
    <div class="alert-text">
        <?php echo e(Session::get('info')); ?><br>
    </div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Fechar">
            <span aria-hidden="true"><i class="la la-close"></i></span>
        </button>
    </div>
</div>
<?php endif; ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/components/alerts.blade.php ENDPATH**/ ?>