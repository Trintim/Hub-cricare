
<?php $__env->startComponent('mail::message'); ?>

#Você recebeu uma mensagem

Nome: <?php echo e($details['name']); ?><br>
Telefone: <?php echo e($details['telefone']); ?><br>
Email: <?php echo e($details['email']); ?><br>
<br>
Motivo: <?php echo e($details['subject']); ?><br>
<br>
Mensagem: <?php echo e($details['message']); ?><br>

Obrigado,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/emails/hubMail.blade.php ENDPATH**/ ?>