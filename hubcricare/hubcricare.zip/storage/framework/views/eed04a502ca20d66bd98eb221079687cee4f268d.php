

<?php $__env->startSection('title', 'Dashbord | Admin'); ?>

<?php $__env->startSection('content'); ?>

<div class="wrapper">
    <div class="container-fluid">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <h4 class="page-title">Seja bem vindo <?php echo e($user->name); ?></h4>
                </div>
            </div>
        </div>
        <!-- end page title end breadcrumb -->

        <div class="row">
        </div>

    </div> <!-- end container -->
</div>
<!-- end wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/admin/home.blade.php ENDPATH**/ ?>