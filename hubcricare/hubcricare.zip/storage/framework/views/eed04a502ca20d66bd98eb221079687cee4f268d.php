

<?php $__env->startSection('title', 'Dashbord | Admin'); ?>

<?php $__env->startSection('content'); ?>

<div class="wrapper">
    <div class="container-fluid">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <h4 class="page-title">Seja bem vindo <?php echo e($user->name); ?></h4>
                </div>
            </div>
        </div> <!-- end container -->
        <!-- Modal -->
        <?php if($aniversariante): ?>
            <?php $__currentLoopData = $aniversariante; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aniversario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="myModalLabel">Aniversariantes Do Dia</h4>
                            </div>
                            <div class="modal-body" style=" display: flex; justify-content: center; align-items: center; flex-direction: column; " >
                                <?php $__currentLoopData = $aniversariante; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aniversario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($aniversario->dt_nasc != null): ?>
                                        <h5 style="font-size: 16px;"><?php echo e($aniversario->name); ?> do setor <?php echo e($aniversario->setor); ?> faz <?php echo e($aniversario->dt_nasc->diffInYears($dataAtual)); ?> Anos</h5>
                                        <h6 style="font-size: 14px;">Hoje <span style="color: #660c0c;"><?php echo e($aniversario->dt_nasc->format('d/m')); ?>/<?php echo e($ano); ?></span></h6>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if($aniversariantesDoMes): ?>
            <?php $__currentLoopData = $aniversariantesDoMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aniversariantes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="myModalLabel">Aniversariantes Do Mês</h4>
                            </div>
                            <div class="modal-body"  style=" display: flex; justify-content: center; align-items: center; flex-direction: column; " >
                                <?php $__currentLoopData = $aniversariantesDoMes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aniversariantes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($aniversariantes->dt_nasc): ?>
                                        <h5 style="font-size: 16px;"><?php echo e($aniversariantes->name); ?> do setor <?php echo e($aniversariantes->setor); ?></h5>
                                        <h6 style="font-size: 14px;">No dia <span style="color: #660c0c;"><?php echo e($aniversariantes->dt_nasc->format('d/m')); ?>/<?php echo e($ano); ?></span></h6>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div> <!-- end wrapper -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/admin/home.blade.php ENDPATH**/ ?>