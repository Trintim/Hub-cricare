

<?php $__env->startSection('title', 'Categorias | Admin'); ?>

<?php $__env->startSection('content'); ?>

<div class="wrapper">
    <div class="container-fluid">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <h4 class="page-title">Categorias de Produto</h4>
                </div>
            </div>
        </div>
        <!-- end page title end breadcrumb -->


        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <?php if(isset($productcategorie)): ?>
                        <h4 class="m-t-0 header-title"><b>Editar Categoria</b></h4>
                        <p class="text-muted font-14 m-b-30">
                            Formulário para editar categoria.
                        </p>
                    <?php else: ?>
                        <h4 class="m-t-0 header-title"><b>Criar nova Categoria</b></h4>
                        <p class="text-muted font-14 m-b-30">
                            Formulário para criar nova categoria.
                        </p>
                    <?php endif; ?>

                    <form id="form-productcategorie" method="POST" action=" <?php echo e(isset($productcategorie) ? route("admin.productCategories.update", $productcategorie->id) : route("admin.productCategories.store")); ?> " enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                        <?php if(isset($productcategorie)): ?>
                        <?php echo method_field("PUT"); ?>
                        <?php else: ?>
                        <?php echo method_field("post"); ?>
                        <?php endif; ?>

                        <?php $__env->startComponent('admin.productcategorie.form', [ "productcategorie" => isset($productcategorie) ? $productcategorie : null ]); ?>
                        <?php echo $__env->renderComponent(); ?>

                    </form>

                    <div class="d-flex justify-content-end mt-3">
                        <button type="submit" form="form-productcategorie" class="btn btn-success mr-2">Salvar</button>
                        <a href=" <?php echo e(route('admin.productCategories.index')); ?>" class="btn btn-secondary">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->

    </div> <!-- end container -->
</div>
<!-- end wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/admin/productcategorie/crud.blade.php ENDPATH**/ ?>