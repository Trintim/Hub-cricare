<div class="form-row">

<div class="form-group col-md-12 col-sm-12">
        <label for="name">Nome do Funcionário:</label>
        <div>
            <input type="text" id="name" name="name" value="<?php echo e(isset($funcionario)? $funcionario->name: old('name')); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Adicione um nome paro o Funcionário...." required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-12 col-sm-12">
        <label class="required" for="email">E-mail</label>
        <div>
            <input type="email" id="email" name="email" value="<?php echo e(isset($funcionario)? $funcionario->email: old('email')); ?>"
                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Adicione um e-mail" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-12 col-sm-12">
        <label class="required" for="phone">Whatsapp</label>
        <div>
            <input type="tel" id="phone" name="phone" value="<?php echo e(isset($funcionario)? $funcionario->phone: old('phone')); ?>"
                class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="" required>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-3 col-sm-12">
        <label for="dt_nasc">Data de Nascimento:</label>
        <div>
            <input type="date" id="dt_nasc" name="dt_nasc" value="<?php echo e(isset($funcionario) ? $funcionario->dt_nasc->format('Y-m-d') : old('dt_nasc')); ?>" class="form-control <?php $__errorArgs = ['dt_nasc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
            <?php $__errorArgs = ['dt_nasc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-9 col-sm-12">
        <label for="setor">Setor:</label>
        <div>
            <input type="text" id="setor" name="setor" value="<?php echo e(isset($funcionario)? $funcionario->setor: old('setor')); ?>" class="form-control <?php $__errorArgs = ['setor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Adicione um Setor...." required>
            <?php $__errorArgs = ['setor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-6 col-sm-12">
        <label for="image">Imagem:</label>
        <input type="file" id="image" name="image" at1="image" class="form-control" accept="image/*" <?php if(isset($funcionario->image)): ?> <?php else: ?> required <?php endif; ?>>
    </div>
    <?php if(isset($funcionario)): ?>
        <div class="form-group col-md-6 col-sm-12">
            <label for="image">Imagem Atual:</label>
            <div><img src="/storage/<?php echo e($funcionario->image); ?>" alt="imagem Serviço" style="max-height: 430px; max-width: 520px; object-fit: cover;"></div>
        </div>
    <?php endif; ?>

    <?php $__env->startSection('script'); ?>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#phone').val(phoneMask($('#phone').val()));
            });
            $("#phone").keypress(function() {
                $('#phone').val(phoneMask($('#phone').val()));
            });
            $("#phone").keydown(function() {
                $('#phone').val(phoneMask($('#phone').val()));
            });
            $("#phone").keyup(function() {
                $('#phone').val(phoneMask($('#phone').val()));
            });
        </script>
    <?php $__env->stopSection(); ?>

</div><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/admin/funcionarios/form.blade.php ENDPATH**/ ?>