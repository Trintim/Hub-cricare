<div class="form-row">
    <div class="form-group col-md-12 col-sm-12">
        <label for="categorie">Nome da Categoria:</label>
        <div>
            <input type="text" id="categorie" name="categorie" value="<?php echo e(isset($productcategorie)? $productcategorie->categorie: old('categorie')); ?>" class="form-control <?php $__errorArgs = ['categorie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Categoria" required>
            <?php $__errorArgs = ['categorie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/admin/productcategorie/form.blade.php ENDPATH**/ ?>