

<?php $__env->startSection('title', 'Hub do Cricaré'); ?>

<?php $__env->startSection('content'); ?>

    <section id="cta" class="cta">
        <div class="container" data-aos="zoom-in">

            <div class="text-center">
                <h3>Confira Nosso Catálogo de Produtos</h3>
            </div>

        </div>
    </section>

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio">
        <div class="container" data-aos="fade-up">

            <div class="section-title">
                <h2>Produtos</h2>
                <p>Todos Os Nossos Produtos</p>
            </div>

            <div class="row" data-aos="fade-up" data-aos-delay="100">
                <div class="col-lg-12 d-flex justify-content-center">
                    <ul id="portfolio-flters">
                        <li data-filter="*" class="filter-active">All</li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-filter=".filter-<?php echo e($categorie->id); ?>"><?php echo e($categorie->categorie); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

                <?php for($i = (count($products)-1); $i >= 0; $i--): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($status == 1): ?>
                <div class="col-lg-4 col-md-6 portfolio-item filter-<?php echo e($products[$i]->productcategorie_id); ?>">
                    <div class="portfolio-wrap">
                        <img src="<?php echo e(url('storage/' . $products[$i]->image)); ?>" class="img-fluid" alt="">
                        <div class="portfolio-info">
                            <h4><?php echo e($products[$i]->name); ?></h4>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($categorie->id == $products[$i]->productcategorie_id): ?>
                            <p><?php echo $categorie->categorie; ?></p>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="portfolio-links">
                                <a href="<?php echo e(route('site.product', $products[$i]->id)); ?>" title="More Details"><i class="bx bx-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endfor; ?>
            </div>

        </div>
    </section><!-- End Portfolio Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', ['status' => 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/site/produtos.blade.php ENDPATH**/ ?>