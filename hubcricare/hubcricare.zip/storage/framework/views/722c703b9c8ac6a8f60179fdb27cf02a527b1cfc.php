

<?php $__env->startSection('title'); ?>
Hub do Cricaré
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    Ola

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/site/detalheproduto.blade.php ENDPATH**/ ?>