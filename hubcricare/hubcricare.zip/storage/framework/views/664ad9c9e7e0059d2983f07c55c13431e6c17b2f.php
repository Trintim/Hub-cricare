<tr>
    <td class="header">
        <a href="#" style="display: inline-block;">
            <?php if(trim($slot) === 'Hub do Cricaré'): ?>
            <h1 style="font-size: 24px; color: #fff">Hub do cricaré</h1>
            <?php else: ?>
            <?php echo e($slot); ?>

            <?php endif; ?>
        </a>
    </td>
</tr><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>