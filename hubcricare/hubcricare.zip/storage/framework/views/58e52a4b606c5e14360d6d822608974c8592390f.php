[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>