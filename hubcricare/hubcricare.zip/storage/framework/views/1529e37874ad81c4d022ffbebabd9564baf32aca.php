<div class="form-row">
    <div class="form-group col-md-12 col-sm-12">
        <label for="name">Nome do Produto:</label>
        <div>
            <input type="text" id="name" name="name" value="<?php echo e(isset($product)? $product->name: old('name')); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Adicione um nome paro o projeto...." required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-12 col-sm-12">
        <label for="description">Descrição:</label>
        <div>
            <textarea id="description" name="description" class="ckeditor form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Adiciona uma descrição" required><?php echo e(isset($product)? $product->description: old('description')); ?></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <i class="fi-circle-cross"></i><strong> <?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group col-md-6">
        <label for="productcategorie_id">Categorias para o Produto:</label>
        <select id="productcategorie_id" name="productcategorie_id" class="form-control" required>
            <option> ->> Selecione uma Categoria <<- </option>
            <?php if(isset($categories)): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option
                        <?php if(isset($product) && $product->productcategorie_id == $categorie->id): ?>
                            selected
                        <?php endif; ?>
                        value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->categorie); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </select>
    </div>

    <div class="form-group col-md-6 col-sm-12">
        <label for="image">Imagem:</label>
        <input type="file" id="image" name="image" at1="image" class="form-control" accept="image/*" <?php if(isset($product->image)): ?> <?php else: ?> required <?php endif; ?>>
    </div>
    <?php if(isset($product)): ?>
        <div class="form-group col-md-6 col-sm-12">
            <label for="image">Imagem Atual:</label>
            <div><img src="/storage/<?php echo e($product->image); ?>" alt="imagem Serviço" style="max-height: 430px; max-width: 520px; object-fit: cover;"></div>
        </div>
     <?php endif; ?>
</div><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/admin/produtos/form.blade.php ENDPATH**/ ?>