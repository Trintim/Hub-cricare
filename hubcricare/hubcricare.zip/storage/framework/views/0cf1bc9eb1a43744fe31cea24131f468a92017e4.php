

<?php $__env->startSection('title', 'Funcionários | Admin'); ?>

<?php $__env->startSection('content'); ?>

<div class="wrapper">
    <div class="container-fluid">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <h4 class="page-title">Funcionários</h4>
                </div>
            </div>
        </div>
        <!-- end page title end breadcrumb -->


        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <?php if(isset($funcionario)): ?>
                        <h4 class="m-t-0 header-title"><b>Editar Funcionários</b></h4>
                        <p class="text-muted font-14 m-b-30">
                            Formulário para edição do Funcionário.
                        </p>
                    <?php else: ?>
                        <h4 class="m-t-0 header-title"><b>Criar novo Funcionário</b></h4>
                        <p class="text-muted font-14 m-b-30">
                            Formulário para criar um novo Funcionário.
                        </p>
                    <?php endif; ?>

                    <form id="form-funcionarios" method="POST" action=" <?php echo e(isset($funcionario) ? route("admin.funcionarios.update", $funcionario->id) : route("admin.funcionarios.store")); ?> " enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                        <?php if(isset($funcionario)): ?>
                            <?php echo method_field("PUT"); ?>
                        <?php else: ?>
                            <?php echo method_field("post"); ?>
                        <?php endif; ?>

                        <?php $__env->startComponent('admin.funcionarios.form', [ "funcionario" => isset($funcionario) ? $funcionario : null]); ?>
                        <?php echo $__env->renderComponent(); ?>

                    </form>

                    <div class="d-flex justify-content-end mt-3">
                    <button type="submit" form="form-funcionarios" class="btn btn-success mr-2">Salvar</button>
                        <a href=" <?php echo e(route('admin.funcionarios.index')); ?>" class="btn btn-secondary">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->

    </div> <!-- end container -->
</div>
<!-- end wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->yieldContent('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\victor.souza\hubof\hubcricare\resources\views/admin/funcionarios/crud.blade.php ENDPATH**/ ?>