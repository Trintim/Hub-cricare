@extends('layout.admin')

@section('title', 'Dashbord | Admin')

@section('content')

<div class="wrapper">
    <div class="container-fluid">

        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="page-title-box">
                    <h4 class="page-title">Seja bem vindo {{$user->name}}</h4>
                </div>
            </div>
        </div>
        <!-- end page title end breadcrumb -->

        <div class="row">
        </div>

    </div> <!-- end container -->
</div>
<!-- end wrapper -->

@endsection